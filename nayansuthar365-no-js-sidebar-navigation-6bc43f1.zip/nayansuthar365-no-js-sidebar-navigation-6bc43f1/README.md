no-js-sidebar-navigation
========================

sidebar navigation for web based apps with only css.